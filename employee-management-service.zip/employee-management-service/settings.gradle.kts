
rootProject.name="employee-management-service"

